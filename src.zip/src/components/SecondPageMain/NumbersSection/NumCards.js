import React from 'react'



function NumCards({countnum}) {
  return (
    <div className="num-cont">
    <h4>{countnum}</h4>
    <p>Cool feature title</p>
</div>
  )
}

export default NumCards