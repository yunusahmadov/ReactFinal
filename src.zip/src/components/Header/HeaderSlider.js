import React from 'react'

function HeaderSlider() {
  return (
    <div className="header-body-bottom">
    <div class="slider">
      <div class="slide-track">
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c7dd27f127a40e6bf26_Presto.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c9adbf69c205b427c5e_Boldo.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c7dd27f127a40e6bf26_Presto.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c9adbf69c205b427c5e_Boldo.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c7dd27f127a40e6bf26_Presto.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c9adbf69c205b427c5e_Boldo.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c7dd27f127a40e6bf26_Presto.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c9adbf69c205b427c5e_Boldo.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c7dd27f127a40e6bf26_Presto.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c9adbf69c205b427c5e_Boldo.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c7dd27f127a40e6bf26_Presto.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c9adbf69c205b427c5e_Boldo.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c7dd27f127a40e6bf26_Presto.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c9adbf69c205b427c5e_Boldo.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c7dd27f127a40e6bf26_Presto.png" alt="" />
        </div>
        <div class="slide">
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f32c9adbf69c205b427c5e_Boldo.png" alt="" />
        </div>
      </div>
    </div>
              </div>

  )
}

export default HeaderSlider