import React from 'react'

function SectionFiveLeft() {
  return (
    <div className='section-five-bottom-left'>
        <p>We connect our customers with the best, and help them keep up-and stay open.</p>
    </div>
  )
}

export default SectionFiveLeft