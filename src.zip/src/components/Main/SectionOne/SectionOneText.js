import React from 'react'

function SectionOneText() {
  return (
    <div className="section-one-text-container">
    <h3>Our Service</h3>
    <p>Handshake infographic mass market crowdfunding iteration.</p>
    </div>
  )
}

export default SectionOneText