import React from 'react'

function SectionThreeRight() {
  return (
      <div className='section-three-container-right'>
          <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f411acb0b5952894a26f4a_Boldo-image-2.png" alt="" />
      </div>
  )
}

export default SectionThreeRight