import React from 'react'

function SectionTwoLeft() {
  return (
    <div className='section-two-container-left'>
            <img src="https://assets.website-files.com/61f3090502b5c6b41663e657/61f40d2ffe1b877d9dd85f25_Boldo-image-1.png" alt="" />
    </div>
  )
}

export default SectionTwoLeft