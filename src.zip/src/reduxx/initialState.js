//Global state
export const initialStates={
logo:{

},
navigation:{

},
headerbody:{
 
},
sectionOneCards:{

},
blog:{
},
cardimg:{
},
userImg:{
},
fiveimgs:{
},
countNums:{
},
things:{
}
}
